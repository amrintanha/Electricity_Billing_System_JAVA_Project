import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Welcome implements ActionListener {
    private JButton exitBtn;
    private JButton nextBtn;
    private Font f1;
    private JFrame frame;

    public Welcome() {
        // Create frame
        frame = new JFrame("Electricity Bill Management System");

        ImageIcon backgroundImg = new ImageIcon("welcome.jpg");

        // Create background label to hold the image
        JLabel backgroundLabel = new JLabel(backgroundImg);
        backgroundLabel.setBounds(0, 0, backgroundImg.getIconWidth(), backgroundImg.getIconHeight());

        // Set Icon for Frame
        ImageIcon icon = new ImageIcon("icon.png");
        frame.setIconImage(icon.getImage());

        // Fonts
        f1 = new Font("Arial", Font.PLAIN, 25);

        // Construct components
        nextBtn = new JButton("Next");
        exitBtn = new JButton("Exit");

        // Set component bounds
        nextBtn.setBounds(950, 600, 200, 50);
        exitBtn.setBounds(100, 600, 200, 50);

        // Set Fonts
        nextBtn.setFont(f1);
        exitBtn.setFont(f1);

        // Set Foreground
        nextBtn.setForeground(Color.WHITE);
        exitBtn.setForeground(Color.WHITE);

        // Set background color for buttons
        nextBtn.setBackground(Color.PINK);
        exitBtn.setBackground(Color.RED);

        // Add action listener
        nextBtn.addActionListener(this);
        exitBtn.addActionListener(this);

        // Add components to frame
        frame.add(nextBtn);
        frame.add(exitBtn);
        frame.add(backgroundLabel);

        // Frame properties
        frame.setSize(1290, 760);
        frame.setLocationRelativeTo(null);
        frame.setLayout(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == nextBtn) {
            frame.dispose(); // Close the Welcome window
            new Home(); // Open the Home window
        } else if (e.getSource() == exitBtn) {
            System.exit(0);
        }
    }

    public void setVisible(boolean visible) {
        frame.setVisible(visible); // Wrapper for JFrame visibility
    }

    public static void main(String[] args) {
        new Welcome();
    }
}