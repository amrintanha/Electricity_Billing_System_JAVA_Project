class PaymentProcessor {

    public boolean processPayment(String cardType, String cardNumber, String cardHolderName, String expiryDate, String cvv) {
        if (cardType.equalsIgnoreCase("Visa") || cardType.equalsIgnoreCase("MasterCard")) {
            return true;
        }
        return false;
    }
}