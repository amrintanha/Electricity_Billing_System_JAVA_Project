import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class Login extends JFrame implements ActionListener {  

    JLabel fullNameLabel;
    JLabel emailLabel;
    JLabel phoneNumberLabel;
    JLabel meterNoLabel;
    JLabel addressLabel;
    JLabel cityLabel;
    JLabel areaLabel;
    JLabel streetNoLabel;
    JTextField username;
    JTextField emailField;
    JTextField phoneNumberField;
    JTextField meterNoField;
    JTextField addressField;
    JTextField cityField;
    JTextField areaField;
    JTextField streetNoField;
    JButton submitBtn;
    JButton resetBtn; 
    JButton backBtn;
    JButton nextBtn;
    JFrame frame;

    // Declare font variables
    Font f1, f2, f3, f4, f5;

    Login() {  
        // Create frame
        frame = new JFrame("Information");

        ImageIcon backgroundImg = new ImageIcon("customer.jpg");

        // Create background label to hold the image
        JLabel imageLabel = new JLabel(backgroundImg);
        imageLabel.setBounds(0, 0, backgroundImg.getIconWidth(), backgroundImg.getIconHeight());

        // Add background label to the content pane
        frame.getContentPane().add(imageLabel);      

        // Construct components
        fullNameLabel = new JLabel("Full Name: ");
        emailLabel = new JLabel("Email: ");
        phoneNumberLabel = new JLabel("Phone Number: ");
        meterNoLabel = new JLabel("Meter No: ");
        addressLabel = new JLabel("Address: ");
        cityLabel = new JLabel("City: ");
        areaLabel = new JLabel("Area: ");
        streetNoLabel = new JLabel("Street No: ");
        username = new JTextField(5);
        emailField = new JTextField(5);
        phoneNumberField = new JTextField(5);
        meterNoField = new JTextField(5);
        addressField = new JTextField(5);
        cityField = new JTextField(5);
        areaField = new JTextField(5);
        streetNoField = new JTextField(5);
        submitBtn = new JButton("Submit");
        resetBtn = new JButton("Reset"); 
        backBtn = new JButton("Back");
        nextBtn = new JButton("Next");

        // Initialize fonts
        f1 = new Font("Times New Roman", Font.PLAIN, 17);
        f2 = new Font("Times New Roman", Font.BOLD, 17);  
        f3 = new Font("Times New Roman", Font.PLAIN, 17);
        f4 = new Font("Times New Roman", Font.PLAIN, 17);
        f5 = new Font("Times New Roman", Font.PLAIN, 17);

        // Add components
        frame.add(fullNameLabel);
        frame.add(emailLabel);
        frame.add(phoneNumberLabel);
        frame.add(meterNoLabel);
        frame.add(addressLabel);
        frame.add(cityLabel);
        frame.add(areaLabel);
        frame.add(streetNoLabel);
        frame.add(username);
        frame.add(emailField);
        frame.add(phoneNumberField);
        frame.add(meterNoField);
        frame.add(addressField);
        frame.add(cityField);
        frame.add(areaField);
        frame.add(streetNoField);
        frame.add(submitBtn);
        frame.add(resetBtn);
        frame.add(backBtn);
        frame.add(nextBtn);
        frame.add(imageLabel);

        // Set component bounds 
        fullNameLabel.setBounds(35, 100, 100, 25);
        emailLabel.setBounds(35, 150, 100, 25);
        phoneNumberLabel.setBounds(35, 200, 120, 25);
        meterNoLabel.setBounds(35, 250, 100, 25);
        addressLabel.setBounds(35, 300, 100, 25);
        cityLabel.setBounds(35, 350, 100, 25);
        areaLabel.setBounds(35, 400, 100, 25);
        streetNoLabel.setBounds(35, 450, 100, 25);
        username.setBounds(155, 100, 200, 25);
        emailField.setBounds(155, 150, 200, 25);
        phoneNumberField.setBounds(155, 200, 200, 25);
        meterNoField.setBounds(155, 250, 200, 25);
        addressField.setBounds(155, 300, 200, 25);
        cityField.setBounds(155, 350, 200, 25);
        areaField.setBounds(155, 400, 200, 25);
        streetNoField.setBounds(155, 450, 200, 25);
        submitBtn.setBounds(35, 550, 100, 30); 
        resetBtn.setBounds(220, 550, 100, 30); 
        backBtn.setBounds(400, 550, 100, 30);
        nextBtn.setBounds(220, 600, 100, 30);

        // Set fonts
        fullNameLabel.setFont(f3);
        emailLabel.setFont(f3);
        phoneNumberLabel.setFont(f3);
        meterNoLabel.setFont(f3);
        addressLabel.setFont(f3);
        cityLabel.setFont(f3);
        areaLabel.setFont(f3);
        streetNoLabel.setFont(f3);
        submitBtn.setFont(f1);
        backBtn.setFont(f1);
        resetBtn.setFont(f1);
        nextBtn.setFont(f1);
        username.setFont(f4);
        emailField.setFont(f1);
        phoneNumberField.setFont(f1);
        meterNoField.setFont(f1);
        addressField.setFont(f1);
        cityField.setFont(f1);
        areaField.setFont(f1);
        streetNoField.setFont(f1);

        // Add action listeners
        submitBtn.addActionListener(this);
        resetBtn.addActionListener(this);
        nextBtn.addActionListener(this);
        backBtn.addActionListener(this);
        nextBtn.addActionListener(this);

        // Frame properties
        frame.setSize(1290, 760);
        frame.setLocationRelativeTo(null); 
        frame.setLayout(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);  
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == submitBtn) {  
            // Retrieve the customer information from the text fields
            String fullName = username.getText().trim();
            String email = emailField.getText().trim();
            String phoneNumber = phoneNumberField.getText().trim();
            String meterNo = meterNoField.getText().trim();
            String address = addressField.getText().trim();
            String city = cityField.getText().trim();
            String area = areaField.getText().trim();
            String streetNo = streetNoField.getText().trim();

            // Validate all fields
            if (fullName.isEmpty() || email.isEmpty() || phoneNumber.isEmpty() || meterNo.isEmpty() || address.isEmpty() || city.isEmpty() || area.isEmpty() || streetNo.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "All fields must be filled!", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                // Pass data to CustomerPanel
                CustomerPanel customerPanel = new CustomerPanel(meterNo, fullName, email, phoneNumber, address, city, area, streetNo);
                frame.dispose(); // Hide the Login frame
            }
        } else if (e.getSource() == resetBtn) {  
            // Handle Reset action
            username.setText("");
            emailField.setText("");
            phoneNumberField.setText("");
            meterNoField.setText("");
            addressField.setText("");
            cityField.setText("");
            areaField.setText("");
            streetNoField.setText("");
            JOptionPane.showMessageDialog(frame, "Form cleared!");
        } else if (e.getSource() == nextBtn) {

    // Open CustomerPanel without submitting the form
    CustomerPanel customerPanel = new CustomerPanel(
        meterNoField.getText().trim(),
        username.getText().trim(),
        emailField.getText().trim(),
        phoneNumberField.getText().trim(),
        addressField.getText().trim(),
        cityField.getText().trim(),
        areaField.getText().trim(),
        streetNoField.getText().trim(),
        false
    );

    frame.dispose();
}else if (e.getSource() == backBtn) {  
            // Handle back action
            frame.dispose();

            Home home = new Home();
            home.setVisible(true); 
        }
    }

    public static void main(String[] args) {
        new Login();
    }
}
