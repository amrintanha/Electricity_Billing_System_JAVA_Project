import javax.swing.*;
import java.awt.event.*;
import java.awt.Color;

import static javax.swing.JOptionPane.showMessageDialog;

public class Home extends JFrame implements ActionListener {  
    
    private JButton loginBtn;
    private JButton registerBtn;
    private JButton exitBtn;
    private JButton adminLoginBtn;
    private JButton staffLoginBtn; 
    private JFrame frame;
    private User[] users;
    private int userCount; 
    
    Home() {
        // Initialize users and userCount
        users = new User[10]; 
        userCount = 0;

        // Create frame
        frame = new JFrame("Home");

        // Load the background image
        ImageIcon backgroundImg = new ImageIcon("image.jpg");

        // Create a label to hold the background image
        JLabel backgroundLabel = new JLabel(backgroundImg);
        backgroundLabel.setBounds(0, 0, backgroundImg.getIconWidth(), backgroundImg.getIconHeight());

        // Add the background label to the content pane of the frame
        frame.getContentPane().add(backgroundLabel);

        // Construct components
        loginBtn = new JButton("Login");
        registerBtn = new JButton("Register");
        exitBtn = new JButton("Exit");
        adminLoginBtn = new JButton("Admin Login");
        staffLoginBtn = new JButton("Staff Login");

        // Set component bounds (swapping positions of exit and staffLogin buttons)
        loginBtn.setBounds(400, 214, 195, 50);
        registerBtn.setBounds(700, 214, 195, 50);
        staffLoginBtn.setBounds(400, 300, 195, 50); 
        adminLoginBtn.setBounds(700, 300, 195, 50);
        exitBtn.setBounds(400, 386, 195, 50); 


        // Set Foreground
        loginBtn.setForeground(Color.BLUE);
        registerBtn.setForeground(Color.BLUE);
        exitBtn.setForeground(Color.RED);
        adminLoginBtn.setForeground(Color.BLUE);
        staffLoginBtn.setForeground(Color.BLUE); 
        

        // Add action listeners
        loginBtn.addActionListener(this);
        registerBtn.addActionListener(this);
        exitBtn.addActionListener(this);
        adminLoginBtn.addActionListener(this);
        staffLoginBtn.addActionListener(this); 

        // Add components to the frame
        frame.add(loginBtn);
        frame.add(registerBtn);
        frame.add(exitBtn);
        frame.add(adminLoginBtn);
        frame.add(staffLoginBtn); 
        frame.add(backgroundLabel);

        // Frame properties
        frame.setSize(1366, 768);
        frame.setLocationRelativeTo(null); 
        frame.setLayout(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }         
    
    public void actionPerformed(ActionEvent e) {  
        if (e.getSource() == loginBtn) {

    int choice = JOptionPane.showConfirmDialog(
        frame,
        "Do you have an account?",
        "Account Check",
        JOptionPane.YES_NO_OPTION
    );

    if (choice == JOptionPane.YES_OPTION) {
        // Yes → Open Login
        Login loginFrame = new Login();
        loginFrame.setVisible(true);
        frame.dispose();

    } else if (choice == JOptionPane.NO_OPTION) {
        // No → Open Register
        Register registerFrame = new Register();
        registerFrame.setVisible(true);
        frame.dispose();
    }
            
        } else if (e.getSource() == registerBtn) {
            // Code for register button action
            JOptionPane.showMessageDialog(null, "Register Button Clicked");
            Register registerFrame = new Register();
            frame.dispose(); 

        } else if (e.getSource() == exitBtn) {
            System.exit(0);
        } else if (e.getSource() == adminLoginBtn) {
            // Code for admin login button action
            JOptionPane.showMessageDialog(null, "Admin Login Button Clicked");
            LoginPanel loginPanel = new LoginPanel();
            frame.dispose();
        } else if (e.getSource() == staffLoginBtn) {  
            JOptionPane.showMessageDialog(null, "Staff Login Button Clicked");
            StaffLoginPanel StaffLoginPanel = new StaffLoginPanel(); 
            frame.dispose();
        }
    }

    public static void main(String[] args) {
        Home frame = new Home();
    }
}
