import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class StaffLoginPanel extends JFrame implements ActionListener {
    // GUI Components
    JButton staffLoginButton, customerManagementButton, billingManagementButton, exitButton;
    JTextField staffUsernameField;
    JPasswordField staffPasswordField;
    JButton staffBackButton, staffExitButton, staffLoginSubmitButton;
    JButton addCustomerButton, editCustomerButton, deactivateCustomerButton, reactivateCustomerButton, backToMainButton, exitCustomerButton;
    JButton viewBillingUpdatesButton, backToMainFromBillingButton, exitBillingButton;
    JList<String> customerList;
    DefaultListModel<String> customerModel;
    List<Customer> customers;
    boolean isStaffLoggedIn = false;

    JPanel mainPanel, loginPanel, customerPanel, billingPanel;

    JTextArea billingUpdatesArea;  
    JButton editBillingButton; 


    public StaffLoginPanel() {
        setTitle("Staff Login System");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1290, 760);
        setLayout(new CardLayout());

        // Initialize customer list
        customers = new ArrayList<>();
        loadCustomers();

        // Main Panel
        mainPanel = new JPanel() {
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                ImageIcon icon = new ImageIcon("staff.jpg");
                g.drawImage(icon.getImage(), 0, 0, getWidth(), getHeight(), this);
            }
        };
        mainPanel.setLayout(null);

        staffLoginButton = new JButton("Staff Login");
        staffLoginButton.setBounds(80, 400, 150, 40);
        staffLoginButton.addActionListener(this);
        mainPanel.add(staffLoginButton);

        customerManagementButton = new JButton("Customer Management");
        customerManagementButton.setBounds(300, 400, 200, 40);
        customerManagementButton.addActionListener(this);
        mainPanel.add(customerManagementButton);

        billingManagementButton = new JButton("Billing Management");
        billingManagementButton.setBounds(560, 400, 200, 40);
        billingManagementButton.addActionListener(this);
        mainPanel.add(billingManagementButton);

        exitButton = new JButton("Exit");
        exitButton.setBounds(340, 470, 150, 40);
        exitButton.addActionListener(this);
        mainPanel.add(exitButton);

        add(mainPanel, "Main");

        // Login Panel
        initLoginPanel();

        // Customer Management Panel
        initCustomerPanel();

        // Billing Management Panel
        initBillingPanel();

        setVisible(true);
    }

    private void initLoginPanel() {
        loginPanel = new JPanel() {
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                ImageIcon icon = new ImageIcon("stafflog.jpg");
                g.drawImage(icon.getImage(), 0, 0, getWidth(), getHeight(), this);
            }
        };
        loginPanel.setLayout(null);

        JLabel staffUsernameLabel = new JLabel("Username:");
        staffUsernameLabel.setBounds(50, 50, 100, 25);
        loginPanel.add(staffUsernameLabel);

        staffUsernameField = new JTextField();
        staffUsernameField.setBounds(150, 50, 160, 25);
        loginPanel.add(staffUsernameField);

        JLabel staffPasswordLabel = new JLabel("Password:");
        staffPasswordLabel.setBounds(50, 100, 100, 25);
        loginPanel.add(staffPasswordLabel);

        staffPasswordField = new JPasswordField();
        staffPasswordField.setBounds(150, 100, 160, 25);
        loginPanel.add(staffPasswordField);

        staffLoginSubmitButton = new JButton("Login");
        staffLoginSubmitButton.setBounds(50, 200, 80, 25);
        staffLoginSubmitButton.addActionListener(this);
        loginPanel.add(staffLoginSubmitButton);

        staffBackButton = new JButton("Back");
        staffBackButton.setBounds(150, 200, 80, 25);
        staffBackButton.addActionListener(this);
        loginPanel.add(staffBackButton);

        staffExitButton = new JButton("Exit");
        staffExitButton.setBounds(250, 200, 80, 25);
        staffExitButton.addActionListener(this);
        loginPanel.add(staffExitButton);

        add(loginPanel, "Login");
    }

    private void initCustomerPanel() {
        customerPanel = new JPanel() {
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                ImageIcon icon = new ImageIcon("stafflog.jpg");
                g.drawImage(icon.getImage(), 0, 0, getWidth(), getHeight(), this);
            }
        };
        customerPanel.setLayout(null);

        customerModel = new DefaultListModel<>();
        refreshCustomerList();
        customerList = new JList<>(customerModel);
        JScrollPane scrollPane = new JScrollPane(customerList);
        scrollPane.setBounds(50, 50, 400, 200);
        customerPanel.add(scrollPane);

        addCustomerButton = new JButton("Add Customer");
        addCustomerButton.setBounds(50, 270, 150, 30);
        addCustomerButton.addActionListener(this);
        customerPanel.add(addCustomerButton);

        editCustomerButton = new JButton("Edit Customer");
        editCustomerButton.setBounds(220, 270, 150, 30);
        editCustomerButton.addActionListener(this);
        customerPanel.add(editCustomerButton);

        deactivateCustomerButton = new JButton("Deactivate");
        deactivateCustomerButton.setBounds(50, 320, 150, 30);
        deactivateCustomerButton.addActionListener(this);
        customerPanel.add(deactivateCustomerButton);

        reactivateCustomerButton = new JButton("Reactivate");
        reactivateCustomerButton.setBounds(220, 320, 150, 30);
        reactivateCustomerButton.addActionListener(this);
        customerPanel.add(reactivateCustomerButton);

        backToMainButton = new JButton("Back");
        backToMainButton.setBounds(50, 370, 150, 30);
        backToMainButton.addActionListener(this);
        customerPanel.add(backToMainButton);

        exitCustomerButton = new JButton("Exit");
        exitCustomerButton.setBounds(220, 370, 150, 30);
        exitCustomerButton.addActionListener(this);
        customerPanel.add(exitCustomerButton);

        add(customerPanel, "Customer");
    }

    private void initBillingPanel() {
        billingPanel = new JPanel() {
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                ImageIcon icon = new ImageIcon("stafflog.jpg");
                g.drawImage(icon.getImage(), 0, 0, getWidth(), getHeight(), this);
            }
        };
        billingPanel.setLayout(null);

        JLabel billingUpdatesLabel = new JLabel("Billing Updates:");
        billingUpdatesLabel.setBounds(50, 50, 200, 25);
        billingPanel.add(billingUpdatesLabel);

        billingUpdatesArea = new JTextArea(); 
        billingUpdatesArea.setBounds(50, 80, 400, 200);
        billingUpdatesArea.setEditable(false);
        loadBillingUpdates(billingUpdatesArea);
        billingPanel.add(billingUpdatesArea);

        editBillingButton = new JButton("Edit"); 
        editBillingButton.setBounds(50, 350, 150, 30);
        editBillingButton.addActionListener(this); 
        billingPanel.add(editBillingButton); 

        backToMainFromBillingButton = new JButton("Back");
        backToMainFromBillingButton.setBounds(50, 300, 150, 30);
        backToMainFromBillingButton.addActionListener(this);
        billingPanel.add(backToMainFromBillingButton);

        exitBillingButton = new JButton("Exit");
        exitBillingButton.setBounds(220, 300, 150, 30);
        exitBillingButton.addActionListener(this);
        billingPanel.add(exitBillingButton);

        add(billingPanel, "Billing");
    }



    private void loadBillingUpdates(JTextArea billingUpdatesArea) {
    try (BufferedReader reader = new BufferedReader(new FileReader(".\\Data\\billing_updates.txt"))) {
        StringBuilder updates = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            updates.append(line).append("\n");
        }
        billingUpdatesArea.setText(updates.toString());
    } catch (IOException e) {
        billingUpdatesArea.setText("No billing updates available.");
        System.err.println("Error reading billing updates: " + e.getMessage());
    }
}

    private void refreshCustomerList() {
        customerModel.clear();
        for (Customer customer : customers) {
            customerModel.addElement(customer.toString());
        }
    }

    private void loadCustomers() {
        File file = new File("Data/customers.txt");

        if (!file.exists()) {
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;

            while ((line = reader.readLine()) != null) {
                String[] data = line.split("\\t", -1);

                if (data.length == 4) {
                    customers.add(new Customer(
                        data[0],
                        data[1],
                        data[2],
                        Boolean.parseBoolean(data[3])
                    ));
                }
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(
                this,
                "Error loading customers: " + ex.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private void saveCustomers() {
        File file = new File("Data/customers.txt");
        file.getParentFile().mkdirs();

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            for (Customer customer : customers) {
                writer.write(
                    customer.name + "\t"
                    + customer.address + "\t"
                    + customer.phone + "\t"
                    + customer.isActive
                );
                writer.newLine();
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(
                this,
                "Error saving customers: " + ex.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private void showStaffDetailsDialog() {
        JTextField staffNameField = new JTextField();
        JTextField staffIDField = new JTextField();
        JTextField staffPhoneField = new JTextField();

        Object[] message = {
            "Staff Name:", staffNameField,
            "Staff ID:", staffIDField,
            "Phone Number:", staffPhoneField
        };

        int option = JOptionPane.showConfirmDialog(this, message, "Enter Staff Details", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            String staffName = staffNameField.getText();
            String staffID = staffIDField.getText();
            String staffPhone = staffPhoneField.getText();

            if (!staffName.isEmpty() && !staffID.isEmpty() && !staffPhone.isEmpty()) {
                saveStaffDetailsToFile(staffName, staffID, staffPhone);
                JOptionPane.showMessageDialog(this, "Staff details saved successfully!");
                isStaffLoggedIn = true;
            } else {
                JOptionPane.showMessageDialog(this, "All fields are required! Please fill them out.");
                showStaffDetailsDialog();
            }
        }
    }

    private void saveStaffDetailsToFile(String name, String id, String phone) {
        try {
            File directory = new File("Data");
            if (!directory.exists()) {
                directory.mkdir();
            }

            File file = new File("Data/staff_data.txt");
            FileWriter writer = new FileWriter(file, true);
            writer.write("Name: " + name + ", ID: " + id + ", Phone: " + phone + "\n");
            writer.close();
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error saving staff details!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void actionPerformed(ActionEvent e) {
        CardLayout cl = (CardLayout) getContentPane().getLayout();
        if (e.getSource() == staffLoginSubmitButton) {
            String username = staffUsernameField.getText();
            String password = new String(staffPasswordField.getPassword());
            if ("staff".equals(username) && "password".equals(password)) {
                JOptionPane.showMessageDialog(this, "Staff login successful!");
                showStaffDetailsDialog();
                cl.show(getContentPane(), "Main");
            } else {
                JOptionPane.showMessageDialog(this, "Invalid username or password!");
            }
        } else if (e.getSource() == staffLoginButton) {
            cl.show(getContentPane(), "Login");
        } else if (e.getSource() == customerManagementButton) {
            if (isStaffLoggedIn) {
                cl.show(getContentPane(), "Customer");
            } else {
                JOptionPane.showMessageDialog(this, "Please log in as staff first.");
            }
        } else if (e.getSource() == billingManagementButton) {
            if (isStaffLoggedIn) {
                cl.show(getContentPane(), "Billing");
            } else {
                JOptionPane.showMessageDialog(this, "Please log in as staff first.");
            } 
        } else if (e.getSource() == addCustomerButton) {
            String name = JOptionPane.showInputDialog(this, "Enter customer name:");
            String address = JOptionPane.showInputDialog(this, "Enter customer address:");
            String phone = JOptionPane.showInputDialog(this, "Enter customer phone:");
            if (name != null && address != null && phone != null) {
                Customer newCustomer = new Customer(name, address, phone, true);
                customers.add(newCustomer);
                saveCustomers();
                refreshCustomerList();
            }        
        } if (e.getSource() == editCustomerButton) {
            int selectedIndex = customerList.getSelectedIndex();
            if (selectedIndex >= 0) {
                Customer selectedCustomer = customers.get(selectedIndex);
                String name = JOptionPane.showInputDialog(this, "Enter New Name:", selectedCustomer.name);
                String address = JOptionPane.showInputDialog(this, "Enter New Address:", selectedCustomer.address);
                String phone = JOptionPane.showInputDialog(this, "Enter New Phone:", selectedCustomer.phone);
                if (name != null && address != null && phone != null) {
                    selectedCustomer.name = name;
                    selectedCustomer.address = address;
                    selectedCustomer.phone = phone;
                    saveCustomers();
                    refreshCustomerList();

                 }
            } else {
                JOptionPane.showMessageDialog(this, "Please select a customer to edit.");
            }
        } if (e.getSource() == deactivateCustomerButton) {
            int selectedIndex = customerList.getSelectedIndex();
            if (selectedIndex >= 0) {
                Customer selectedCustomer = customers.get(selectedIndex);
                if (selectedCustomer.isActive) {
                    selectedCustomer.isActive = false;
                    saveCustomers();
                    refreshCustomerList();
                } else {
                    JOptionPane.showMessageDialog(this, "Customer is already inactive.");
                }
            } else {
                JOptionPane.showMessageDialog(this, "Please select a customer to deactivate.");
            }
        } else if (e.getSource() == reactivateCustomerButton) {
            int selectedIndex = customerList.getSelectedIndex();
            if (selectedIndex >= 0) {
                Customer selectedCustomer = customers.get(selectedIndex);
                if (!selectedCustomer.isActive) {
                    selectedCustomer.isActive = true;
                    saveCustomers();
                    refreshCustomerList();
                } else {
                    JOptionPane.showMessageDialog(this, "Customer is already active.");
                }
            } else {
                JOptionPane.showMessageDialog(this, "Please select a customer to reactivate.");
            }


        } else if (e.getSource() == backToMainButton || e.getSource() == backToMainFromBillingButton || e.getSource() == staffBackButton) {
            cl.show(getContentPane(), "Main");
        } else if (e.getSource() == exitButton ) {
            cl.show(getContentPane(), "Main");

            Home home = new Home();
            home.setVisible(true); 
        
        } else if (e.getSource() == staffExitButton || e.getSource() == exitCustomerButton || e.getSource() == exitBillingButton) {
            System.exit(0);
        }  else if (e.getSource() == editBillingButton) {
            String newUpdate = JOptionPane.showInputDialog(this, "Edit Billing Update:");
            if (newUpdate != null && !newUpdate.trim().isEmpty()) {
                try (BufferedWriter writer = new BufferedWriter(new FileWriter(".\\Data\\billing_updates.txt", true))) {
                    writer.write(newUpdate);
                    writer.newLine();
                    loadBillingUpdates(billingUpdatesArea);
                    JOptionPane.showMessageDialog(this, "Billing update added!");
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(this, "Error writing to file.");
                    ex.printStackTrace();
                }
            }
        }
    }

    
    public static void main(String[] args) {
        new StaffLoginPanel();
    }

    class Customer {
        String name, address, phone;
        boolean isActive;

        Customer(String name, String address, String phone, boolean isActive) {
            this.name = name;
            this.address = address;
            this.phone = phone;
            this.isActive = isActive;
        }
        

        public String toString() {
            return name + " - " + address + " - " + phone + " - " + (isActive ? "Active" : "Inactive");
        }
    }
}
