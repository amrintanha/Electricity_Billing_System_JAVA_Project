import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import java.util.*;
import java.text.SimpleDateFormat;


public class CustomerPanel implements ActionListener {

    private JFrame frame;
    private JLabel customerIDLabel, customerNameLabel, unitLabel, paymentStatusLabel, monthLabel, paymentStatusValueLabel, amountLabel;
    private JTextField customerIDTextField, customerNameTextField, unitTextField;
    private JButton backButton, printButton, paymentButton;
    private JComboBox<String> monthComboBox;
    private JFrame printFrame;
    private JLabel printCustomerIDLabel, printCustomerNameLabel, printUnitLabel, printPaymentStatusLabel, printMonthLabel, printAmountLabel, printDateLabel, printPaymentIDLabel, printBillIDLabel;
    private HashMap<String, String> paymentStatuses;

    private String meterNo, fullName, email, phoneNumber, address, city, area, streetNo;

    // This controls whether the dashboard information has been completed
    private boolean informationCompleted;

    private static int customerCounter = 1000;


    // Constructor for loading saved customer data from file
    public CustomerPanel(String filePath) {

        informationCompleted = true;

        loadCustomerDataFromKeyValueFile(filePath);
        initializeComponents();
    }


    // Original 8-parameter constructor    
    public CustomerPanel(String meterNo, String fullName, String email,
                         String phoneNumber, String address, String city,
                         String area, String streetNo) {

        this(meterNo, fullName, email, phoneNumber, address, city, area, streetNo, true);
    }


    // Constructor used when opening CustomerPanel from Login
    public CustomerPanel(String meterNo, String fullName, String email,
                         String phoneNumber, String address, String city,
                         String area, String streetNo,
                         boolean informationCompleted) {

        this.meterNo = meterNo;
        this.fullName = fullName;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.address = address;
        this.city = city;
        this.area = area;
        this.streetNo = streetNo;

        this.informationCompleted = informationCompleted;

        initializeComponents();
    }


    // Checks whether Login/Dashboard information was completed
    private boolean checkInformationCompleted() {

        if (!informationCompleted) {

            JOptionPane.showMessageDialog(
                frame,
                "Please fill up all fields in the dashboard first!",
                "Warning",
                JOptionPane.WARNING_MESSAGE
            );

            return false;
        }

        return true;
    }


    // Shows warning when user tries to type/click locked fields
    private void showDashboardWarning() {

        if (!informationCompleted) {

            JOptionPane.showMessageDialog(
                frame,
                "Please fill up all fields in the dashboard first!",
                "Warning",
                JOptionPane.WARNING_MESSAGE
            );
        }
    }


    // Protect a text field when dashboard information is incomplete
    private void protectTextField(JTextField textField) {

        textField.addKeyListener(new KeyAdapter() {

            
            public void keyPressed(KeyEvent e) {

                if (!informationCompleted) {

                    e.consume();
                    showDashboardWarning();
                }
            }
        });


        textField.addMouseListener(new MouseAdapter() {

            
            public void mousePressed(MouseEvent e) {

                if (!informationCompleted) {

                    showDashboardWarning();
                }
            }
        });
    }


    private void loadCustomerDataFromKeyValueFile(String filePath) {

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {

            Properties properties = new Properties();
            properties.load(reader);

            meterNo = properties.getProperty("MeterNo");
            fullName = properties.getProperty("FullName");
            email = properties.getProperty("Email");
            phoneNumber = properties.getProperty("PhoneNumber");
            address = properties.getProperty("Address");
            city = properties.getProperty("City");
            area = properties.getProperty("Area");
            streetNo = properties.getProperty("StreetNo");

        } catch (IOException e) {

            System.err.println("Error reading from file: " + e.getMessage());
        }
    }


    private void saveCustomerDataToFile(String filePath) {

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath, true))) {

            String selectedMonth = (String) monthComboBox.getSelectedItem();
            String updatedPaymentStatus = paymentStatuses.get(selectedMonth);

            writer.write("MeterNo=" + meterNo + "\n");
            writer.write("FullName=" + fullName + "\n");
            writer.write("Email=" + email + "\n");
            writer.write("PhoneNumber=" + phoneNumber + "\n");
            writer.write("Address=" + address + "\n");
            writer.write("City=" + city + "\n");
            writer.write("Area=" + area + "\n");
            writer.write("StreetNo=" + streetNo + "\n");
            writer.write("CustomerID=" + customerIDTextField.getText() + "\n");
            writer.write("CustomerName=" + customerNameTextField.getText() + "\n");
            writer.write("Unit=" + unitTextField.getText() + "\n");
            writer.write("Month=" + monthComboBox.getSelectedItem() + "\n");
            writer.write("PaymentStatus=" + paymentStatuses.get(monthComboBox.getSelectedItem()) + "\n");
            writer.write("Amount=" + amountLabel.getText().split(" ")[1] + "\n");
            writer.write("DateTime=" + new java.util.Date() + "\n");
            writer.write("\n");

            writer.flush();

        } catch (IOException e) {

            System.err.println("Error saving customer data: " + e.getMessage());
        }
    }


    private String generateCustomerID() {

        return "CUST" + System.currentTimeMillis();
    }


    private String generateBillID() {

        return "BILL" + System.currentTimeMillis();
    }


    private void initializeComponents() {

        frame = new JFrame("Customer Panel");

        ImageIcon backgroundImg = new ImageIcon("Payment.jpg");
        JLabel imageLabel = new JLabel(backgroundImg);
        imageLabel.setBounds(0, 0, backgroundImg.getIconWidth(), backgroundImg.getIconHeight());

        frame.setLayout(null);
        frame.add(imageLabel);

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1290, 760);

        initializeInputFieldsAndLabels(imageLabel);
        initializeButtons(imageLabel);
        initializeComboBox(imageLabel);
        initializePrintFrame();

        frame.setVisible(true);
        
        
        

        paymentStatuses = new HashMap<>();

        for (String month : getMonths()) {

            paymentStatuses.put(month, "Pending");
        }

        customerIDTextField.setText(generateCustomerID());
    }


    


    private void initializeInputFieldsAndLabels(JLabel imageLabel) {

        customerIDLabel = createLabel("Customer ID:", 220, 80);
        customerNameLabel = createLabel("Customer Name:", 220, 110);
        unitLabel = createLabel("Unit:", 220, 140);
        paymentStatusLabel = createLabel("Payment Status:", 220, 170);
        paymentStatusValueLabel = createLabel("Pending", 330, 170);
        monthLabel = createLabel("Month:", 220, 200);
        amountLabel = createLabel("Amount: 0.0 Taka", 220, 230);

        customerIDTextField = createTextField(330, 80);
        customerNameTextField = createTextField(330, 110);
        unitTextField = createTextField(330, 140);


        // Customer ID field protection
        protectTextField(customerIDTextField);


        // Customer Name field protection
        protectTextField(customerNameTextField);


        // Unit field
        unitTextField.addKeyListener(new KeyAdapter() {

            
            public void keyPressed(KeyEvent e) {

                if (!informationCompleted) {

                    e.consume();
                    showDashboardWarning();

                    return;
                }
            }


            
            public void keyReleased(KeyEvent e) {

                if (!informationCompleted) {

                    return;
                }

                calculateAndUpdateAmount();
            }
        });


        unitTextField.addMouseListener(new MouseAdapter() {

            
            public void mousePressed(MouseEvent e) {

                if (!informationCompleted) {

                    showDashboardWarning();
                }
            }
        });


        imageLabel.add(customerIDLabel);
        imageLabel.add(customerNameLabel);
        imageLabel.add(unitLabel);
        imageLabel.add(paymentStatusLabel);
        imageLabel.add(paymentStatusValueLabel);
        imageLabel.add(monthLabel);
        imageLabel.add(amountLabel);

        imageLabel.add(customerIDTextField);
        imageLabel.add(customerNameTextField);
        imageLabel.add(unitTextField);
    }


    private void initializeButtons(JLabel imageLabel) {

        paymentButton = createButton("Make Payment", 330, 280);
        backButton = createButton("Back", 160, 330);
        printButton = createButton("Print", 450, 330);

        paymentButton.addActionListener(this);
        backButton.addActionListener(this);
        printButton.addActionListener(this);

        imageLabel.add(paymentButton);
        imageLabel.add(backButton);
        imageLabel.add(printButton);
    }


    private void initializeComboBox(JLabel imageLabel) {

        monthComboBox = new JComboBox<>(getMonths());

        monthComboBox.setBounds(330, 200, 150, 20);

        monthComboBox.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {

                if (!informationCompleted) {

                    monthComboBox.setSelectedIndex(0);

                    showDashboardWarning();
                }
            }
        });


        monthComboBox.addMouseListener(new MouseAdapter() {

            @Override
            public void mousePressed(MouseEvent e) {

                if (!informationCompleted) {

                    showDashboardWarning();
                }
            }
        });


        imageLabel.add(monthComboBox);
    }


    private void initializePrintFrame() {

        printFrame = new JFrame("Print Bill");

        printFrame.setSize(450, 450);

        printFrame.setVisible(false);

        printFrame.setLayout(null);

        printPaymentIDLabel = createLabel("Payment ID:", 20, 20);
        printBillIDLabel = createLabel("Bill ID:", 20, 50);
        printCustomerIDLabel = createLabel("Customer ID:", 20, 80);
        printCustomerNameLabel = createLabel("Customer Name:", 20, 110);
        printUnitLabel = createLabel("Unit:", 20, 140);
        printPaymentStatusLabel = createLabel("Payment Status:", 20, 170);
        printMonthLabel = createLabel("Month:", 20, 200);
        printAmountLabel = createLabel("Amount Paid:", 20, 230);
        printDateLabel = createLabel("Payment Date:", 20, 260);

        printFrame.add(printPaymentIDLabel);
        printFrame.add(printBillIDLabel);
        printFrame.add(printCustomerIDLabel);
        printFrame.add(printCustomerNameLabel);
        printFrame.add(printUnitLabel);
        printFrame.add(printPaymentStatusLabel);
        printFrame.add(printMonthLabel);
        printFrame.add(printAmountLabel);
        printFrame.add(printDateLabel);
    }


    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == backButton) {

            frame.dispose();

            new Login();

        }

        else if (e.getSource() == printButton) {

            if (!checkInformationCompleted()) {

                return;
            }

            printFrame.setVisible(true);
        }

        else if (e.getSource() == paymentButton) {

            if (!checkInformationCompleted()) {

                return;
            }

            showPaymentMethodSelectionDialog();
        }
    }


    private void showPaymentMethodSelectionDialog() {

        String[] paymentMethods = {
            "Visa/MasterCard",
            "bKash",
            "Rocket"
        };

        JComboBox<String> paymentMethodDropdown =
                new JComboBox<>(paymentMethods);

        int option = JOptionPane.showConfirmDialog(
                null,
                paymentMethodDropdown,
                "Choose Payment Method",
                JOptionPane.OK_CANCEL_OPTION
        );


        if (option == JOptionPane.OK_OPTION) {

            String selectedPaymentMethod =
                    (String) paymentMethodDropdown.getSelectedItem();


            if ("Visa/MasterCard".equals(selectedPaymentMethod)) {

                showCardPaymentDialog();

            }

            else if ("bKash".equals(selectedPaymentMethod)
                    || "Rocket".equals(selectedPaymentMethod)) {

                showMobilePaymentDialog(selectedPaymentMethod);
            }
        }
    }


    private void showCardPaymentDialog() {

        JTextField[] cardFields = new JTextField[4];

        for (int i = 0; i < cardFields.length; i++) {

            cardFields[i] = new JTextField();
        }


        Object[] message = new Object[]{

            "Card Type (Visa/MasterCard):",
            cardFields[0],

            "Card Number:",
            cardFields[1],

            "Card Holder Name:",
            cardFields[2],

            "Expiry Date (MM/YY):",
            cardFields[3]
        };


        int option = JOptionPane.showConfirmDialog(
                null,
                message,
                "Enter Card Payment Details",
                JOptionPane.OK_CANCEL_OPTION
        );


        if (option == JOptionPane.OK_OPTION) {

            String amount =
                    amountLabel.getText().split(" ")[1];

            String month =
                    (String) monthComboBox.getSelectedItem();

            String paymentId =
                    generatePaymentId();

            paymentStatuses.put(month, "Success");

            paymentStatusValueLabel.setText("Success");


            saveBillingUpdate(
                    customerNameTextField.getText(),
                    "Visa/MasterCard"
            );


            updatePrintFrame(
                    customerIDTextField.getText(),
                    customerNameTextField.getText(),
                    unitTextField.getText(),
                    meterNo,
                    "Success",
                    month,
                    amount,
                    paymentId
            );


            saveCustomerDataToFile(
                    ".\\Data\\customer_data.txt"
            );
        }
    }


    private void showMobilePaymentDialog(String paymentMethod) {

        JTextField phoneField = new JTextField();

        JPasswordField pinField = new JPasswordField();


        Object[] message = new Object[]{

            paymentMethod + " Phone Number:",
            phoneField,

            paymentMethod + " PIN:",
            pinField
        };


        int option = JOptionPane.showConfirmDialog(
                null,
                message,
                "Enter " + paymentMethod + " Payment Details",
                JOptionPane.OK_CANCEL_OPTION
        );


        if (option == JOptionPane.OK_OPTION) {

            String amount =
                    amountLabel.getText().split(" ")[1];

            String month =
                    (String) monthComboBox.getSelectedItem();

            String paymentId =
                    generatePaymentId();


            paymentStatuses.put(month, "Success");

            paymentStatusValueLabel.setText("Success");


            saveBillingUpdate(
                    customerNameTextField.getText(),
                    paymentMethod
            );


            updatePrintFrame(
                    customerIDTextField.getText(),
                    customerNameTextField.getText(),
                    unitTextField.getText(),
                    meterNo,
                    "Success",
                    month,
                    amount,
                    paymentId
            );


            saveCustomerDataToFile(
                    ".\\Data\\customer_data.txt"
            );
        }
    }


    private void saveBillingUpdate(
            String customerName,
            String paymentMethod) {

        try (BufferedWriter writer =
                     new BufferedWriter(
                             new FileWriter(
                                     ".\\Data\\billing_updates.txt",
                                     true))) {

            writer.write(
                    "Bill paid by "
                    + customerName
                    + " via "
                    + paymentMethod
                    + ".\n"
            );

        } catch (IOException e) {

            System.err.println(
                    "Error saving billing update: "
                    + e.getMessage()
            );
        }
    }


    private void updatePrintFrame(
            String customerID,
            String customerName,
            String unit,
            String meterNo,
            String paymentStatus,
            String month,
            String amount,
            String paymentId) {


        SimpleDateFormat dateFormat =
                new SimpleDateFormat(
                        "dd-MM-yyyy HH:mm:ss"
                );


        String formattedDate =
                dateFormat.format(
                        new java.util.Date()
                );


        printPaymentIDLabel.setText(
                "Payment ID: " + paymentId
        );

        printBillIDLabel.setText(
                "Bill ID: " + generateBillID()
        );

        printCustomerIDLabel.setText(
                "Customer ID: " + customerID
        );

        printCustomerNameLabel.setText(
                "Customer Name: " + customerName
        );

        printUnitLabel.setText(
                "Unit: " + unit
        );

        printPaymentStatusLabel.setText(
                "Payment Status: " + paymentStatus
        );

        printMonthLabel.setText(
                "Month: " + month
        );

        printAmountLabel.setText(
                "Amount Paid: " + amount + " Taka"
        );

        printDateLabel.setText(
                "Payment Date & Time: " + formattedDate
        );


        printFrame.setVisible(true);
    }


    private void calculateAndUpdateAmount() {

        try {

            double units =
                    Double.parseDouble(
                            unitTextField.getText()
                    );

            double amount =
                    calculateBill(units);

            amountLabel.setText(
                    "Amount: " + amount + " Taka"
            );

        } catch (NumberFormatException e) {

            amountLabel.setText(
                    "Amount: 0.0 Taka"
            );
        }
    }


    private JLabel createLabel(
            String text,
            int x,
            int y) {

        JLabel label = new JLabel(text);

        label.setBounds(
                x,
                y,
                300,
                20
        );

        return label;
    }


    private JTextField createTextField(
            int x,
            int y) {

        JTextField textField =
                new JTextField(20);

        textField.setBounds(
                x,
                y,
                200,
                20
        );

        return textField;
    }


    private JButton createButton(
            String text,
            int x,
            int y) {

        JButton button =
                new JButton(text);

        button.setBounds(
                x,
                y,
                150,
                30
        );

        return button;
    }


    private String[] getMonths() {

        return new String[]{
            "January",
            "February",
            "March",
            "April",
            "May",
            "June",
            "July",
            "August",
            "September",
            "October",
            "November",
            "December"
        };
    }


    private String generatePaymentId() {

        return "PAY" + System.currentTimeMillis();
    }


    private double calculateBill(double units) {

        double billToPay = 0;

        if (units < 100) {

            billToPay = units * 1.20;

        }

        else if (units < 300) {

            billToPay =
                    100 * 1.20
                    + (units - 100) * 2;

        }

        else if (units > 300) {

            billToPay =
                    100 * 1.20
                    + 200 * 2
                    + (units - 300) * 3;
        }

        return billToPay;
    }


    public static void main(String[] args) {

        CustomerPanel customerPanel =
                new CustomerPanel(
                        ".\\Data\\customer_data.txt"
                );
    }
}