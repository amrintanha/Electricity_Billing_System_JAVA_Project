import java.awt.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;

public class LoginPanel extends JFrame implements ActionListener {

    JButton adminLoginButton, userDataButton, exitButton;
    JTextField adminNameTextField;
    JPasswordField adminPasswordField;
    JButton adminBackButton, adminExitButton, adminLoginSubmitButton;
    JTextField userNameTextField, userEmailTextField;
    JPasswordField userPasswordField;
    JButton userRefreshButton, userAddButton, userDeleteButton, userExitButton, userBackButton;
    JList<String> userList;
    JPanel mainPanel, adminPanel, userPanel;
    DefaultListModel<String> userModel;
    List<User> users;

    boolean isAdminLoggedIn = false;

    public LoginPanel() {
        setTitle("Login Panel");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1290, 760);
        setLayout(new CardLayout());

        users = new ArrayList<>();
        loadUsers();

        // Main panel
        mainPanel = new JPanel();
        mainPanel.setLayout(null);

        adminLoginButton = new JButton("Admin Log");
        adminLoginButton.setBounds(80, 400, 150, 40);
        adminLoginButton.addActionListener(this);
        mainPanel.add(adminLoginButton);

        userDataButton = new JButton("User Data");
        userDataButton.setBounds(300, 400, 150, 40);
        userDataButton.addActionListener(this);
        mainPanel.add(userDataButton);

        exitButton = new JButton("Exit");
        exitButton.setBounds(165, 470, 150, 40);
        exitButton.addActionListener(this);
        mainPanel.add(exitButton);

        add(mainPanel, "Main");

        // Admin panel
        initAdminPanel();

        // User panel
        initUserPanel();

        // Add background image to main panel
        ImageIcon backgroundImg = new ImageIcon("Admin.jpg");
        JLabel imageLabel = new JLabel(backgroundImg);
        imageLabel.setBounds(0, 0, backgroundImg.getIconWidth(), backgroundImg.getIconHeight());
        mainPanel.add(imageLabel);

        setVisible(true);
    }

    private void initAdminPanel() {
        adminPanel = new JPanel();
        adminPanel.setLayout(null);

        JLabel adminNameLabel = new JLabel("Username:");
        adminNameLabel.setBounds(50, 50, 80, 25);
        adminPanel.add(adminNameLabel);

        adminNameTextField = new JTextField();
        adminNameTextField.setBounds(150, 50, 160, 25);
        adminPanel.add(adminNameTextField);

        JLabel adminPasswordLabel = new JLabel("Password:");
        adminPasswordLabel.setBounds(50, 100, 80, 25);
        adminPanel.add(adminPasswordLabel);

        adminPasswordField = new JPasswordField();
        adminPasswordField.setBounds(150, 100, 160, 25);
        adminPanel.add(adminPasswordField);

        adminBackButton = new JButton("Back");
        adminBackButton.setBounds(50, 200, 80, 25);
        adminBackButton.addActionListener(this);
        adminPanel.add(adminBackButton);

        adminExitButton = new JButton("Exit");
        adminExitButton.setBounds(150, 200, 80, 25);
        adminExitButton.addActionListener(this);
        adminPanel.add(adminExitButton);

        adminLoginSubmitButton = new JButton("Login");
        adminLoginSubmitButton.setBounds(250, 200, 80, 25);
        adminLoginSubmitButton.addActionListener(this);
        adminPanel.add(adminLoginSubmitButton);

        // Add background image to admin panel
        ImageIcon backgroundImg = new ImageIcon("Admin.jpg");
        JLabel imageLabel = new JLabel(backgroundImg);
        imageLabel.setBounds(0, 0, backgroundImg.getIconWidth(), backgroundImg.getIconHeight());
        adminPanel.add(imageLabel);

        add(adminPanel, "Admin");
    }

    private void initUserPanel() {
        userPanel = new JPanel();
        userPanel.setLayout(null);

        JLabel userNameLabel = new JLabel("Username:");
        userNameLabel.setBounds(100, 60, 120, 30);
        userPanel.add(userNameLabel);

        userNameTextField = new JTextField();
        userNameTextField.setBounds(240, 60, 200, 30);
        userPanel.add(userNameTextField);

        JLabel userEmailLabel = new JLabel("Email:");
        userEmailLabel.setBounds(100, 110, 120, 30);
        userPanel.add(userEmailLabel);

        userEmailTextField = new JTextField();
        userEmailTextField.setBounds(240, 110, 200, 30);
        userPanel.add(userEmailTextField);

        JLabel userPasswordLabel = new JLabel("Password:");
        userPasswordLabel.setBounds(100, 160, 120, 30);
        userPanel.add(userPasswordLabel);

        userPasswordField = new JPasswordField();
        userPasswordField.setBounds(240, 160, 200, 30);
        userPanel.add(userPasswordField);

        userRefreshButton = new JButton("Refresh");
        userRefreshButton.setBounds(100, 220, 120, 30);
        userRefreshButton.addActionListener(this);
        userPanel.add(userRefreshButton);

        userAddButton = new JButton("Add");
        userAddButton.setBounds(240, 220, 120, 30);
        userAddButton.addActionListener(this);
        userPanel.add(userAddButton);

        userDeleteButton = new JButton("Delete");
        userDeleteButton.setBounds(380, 220, 120, 30);
        userDeleteButton.addActionListener(this);
        userPanel.add(userDeleteButton);

        userBackButton = new JButton("Back");
        userBackButton.setBounds(100, 280, 120, 30);
        userBackButton.addActionListener(this);
        userPanel.add(userBackButton);

        userExitButton = new JButton("Exit");
        userExitButton.setBounds(380, 280, 120, 30);
        userExitButton.addActionListener(this);
        userPanel.add(userExitButton);

        userModel = new DefaultListModel<>();
        refreshUserList();

        userList = new JList<>(userModel);
        JScrollPane scrollPane = new JScrollPane(userList);
        scrollPane.setBounds(100, 340, 400, 150);
        userPanel.add(scrollPane);

        // Add background image to user panel
        ImageIcon backgroundImg = new ImageIcon("Admin.jpg");
        JLabel imageLabel = new JLabel(backgroundImg);
        imageLabel.setBounds(0, 0, backgroundImg.getIconWidth(), backgroundImg.getIconHeight());
        userPanel.add(imageLabel);

        add(userPanel, "User");
    }

    private void refreshUserList() {
        userModel.clear();
        for (int i = 0; i < users.size(); i++) {
            User user = users.get(i);
            userModel.addElement(user.toString());
        }
    }

    private void loadUsers() {
        File file = new File("Data" + File.separator + "users.txt");

        if (!file.exists()) {
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;

            while ((line = reader.readLine()) != null) {
                String[] data = line.split("\\t", -1);

                if (data.length == 3) {
                    users.add(new User(data[0], data[1], data[2]));
                }
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(
                    this,
                    "Error loading users: " + ex.getMessage()
            );
        }
    }

    private void saveUsers() {
        File file = new File("Data" + File.separator + "users.txt");
        file.getParentFile().mkdirs();

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            for (User user : users) {
                writer.write(user.name + "\t" + user.email + "\t" + user.password);
                writer.newLine();
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(
                    this,
                    "Error saving users: " + ex.getMessage()
            );
        }
    }

    public void actionPerformed(ActionEvent e) {
        CardLayout cl = (CardLayout) getContentPane().getLayout();

        if (e.getSource() == adminLoginButton) {
            cl.show(getContentPane(), "Admin");
        } else if (e.getSource() == userDataButton) {
            if (isAdminLoggedIn) {
                cl.show(getContentPane(), "User");
            } else {
                JOptionPane.showMessageDialog(this, "Please log in as admin first!");
            }
        } else if (e.getSource() == exitButton) {

            Home home = new Home();
            home.setVisible(true);
            dispose();


        } else if (e.getSource() == adminExitButton || e.getSource() == userExitButton) {
            System.exit(0);
        } else if (e.getSource() == adminBackButton || e.getSource() == userBackButton) {
            cl.show(getContentPane(), "Main");
        } else if (e.getSource() == adminLoginSubmitButton) {
            String name = adminNameTextField.getText();
            String password = new String(adminPasswordField.getPassword());
            if ("admin".equals(name) && "1111".equals(password)) {
                JOptionPane.showMessageDialog(this, "Admin login successful!");
                isAdminLoggedIn = true;

                JTextField adminNameField = new JTextField();
                JTextField adminIDField = new JTextField();
                JTextField adminEmailField = new JTextField();
                JTextField adminPhoneField = new JTextField();

                Object[] message = {
                    "Admin Name:", adminNameField,
                    "Admin ID:", adminIDField,
                    "Admin Email:", adminEmailField,
                    "Admin Phone:", adminPhoneField
                };

                int option = JOptionPane.showConfirmDialog(this, message, "Admin Details", JOptionPane.OK_CANCEL_OPTION);
                if (option == JOptionPane.OK_OPTION) {
                    String adminName = adminNameField.getText();
                    String adminID = adminIDField.getText();
                    String adminEmail = adminEmailField.getText();
                    String adminPhone = adminPhoneField.getText();

                    if (!adminName.isEmpty() && !adminID.isEmpty() && !adminEmail.isEmpty() && !adminPhone.isEmpty()) {
                        saveAdminData(adminName, adminID, adminEmail, adminPhone);
                        JOptionPane.showMessageDialog(this, "Admin details saved successfully!");
                    } else {
                        JOptionPane.showMessageDialog(this, "Please fill all fields!");
                    }
                }
            } else {
                JOptionPane.showMessageDialog(this, "Invalid username or password!");
            }

        } else if (e.getSource() == userRefreshButton) {
            refreshUserList();
        } else if (e.getSource() == userAddButton) {
            String userName = userNameTextField.getText();
            String email = userEmailTextField.getText();
            String password = new String(userPasswordField.getPassword());
            if (!userName.isEmpty() && !email.isEmpty() && !password.isEmpty()) {
                users.add(new User(userName, email, password));
                saveUsers();
                refreshUserList();
                JOptionPane.showMessageDialog(this, "User added successfully!");
            } else {
                JOptionPane.showMessageDialog(this, "Please fill all fields!");
            }
        } else if (e.getSource() == userDeleteButton) {
            int selectedIndex = userList.getSelectedIndex();
            if (selectedIndex != -1) {
                users.remove(selectedIndex);
                saveUsers();
                refreshUserList();
                JOptionPane.showMessageDialog(this, "User deleted successfully!");
            } else {
                JOptionPane.showMessageDialog(this, "Please select a user to delete!");
            }
        }
    }

    private void saveAdminData(String name, String adminID, String adminEmail, String adminPhone) {
        try {
            File file = new File("Data" + File.separator + "admin_data.txt");
            file.getParentFile().mkdirs(); // Ensure the directory exists
            BufferedWriter writer = new BufferedWriter(new FileWriter(file, true));
            writer.write("Admin Name: " + name + ", Admin ID: " + adminID + ", Email: " + adminEmail + ", Phone: " + adminPhone);
            writer.newLine();
            writer.close();
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error saving admin data: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        new LoginPanel();
    }

    class User {
        private String name;
        private String email;
        private String password;

        public User(String name, String email, String password) {
            this.name = name;
            this.email = email;
            this.password = password;
        }

        public String toString() {
            return "Name: " + name + ", Email: " + email;
        }
    }
}
