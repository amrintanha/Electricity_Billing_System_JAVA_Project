import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class Register extends JFrame implements ActionListener {

    // GUI Components
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton registerBtn, resetBtn, backBtn;
    private Font f1, f2, f3, f4, f5;
    private JFrame frame;

    // Constructor to set up the register page
    public Register() {
        // Create and set up the frame
        frame = new JFrame("Register Page");
        frame.setSize(1366, 768);
        frame.setLocationRelativeTo(null);
        frame.setLayout(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Load background image
        ImageIcon backgroundImg = new ImageIcon(getClass().getResource("register.jpg"));
        JLabel backgroundLabel = new JLabel(backgroundImg);
        backgroundLabel.setBounds(0, 0, backgroundImg.getIconWidth(), backgroundImg.getIconHeight());

        f1 = new Font("Times New Roman", Font.PLAIN, 25);
        f2 = new Font("Times New Roman", Font.BOLD, 35);
        f3 = new Font("Times New Roman", Font.PLAIN, 30);
        f4 = new Font("Times New Roman", Font.PLAIN, 22);
        f5 = new Font("Times New Roman", Font.PLAIN, 25);

        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setFont(f3);
        usernameLabel.setBounds(100, 145, 500, 50);

        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setFont(f3);
        passwordLabel.setBounds(100, 205, 500, 50);

        usernameField = new JTextField();
        usernameField.setFont(f4);
        usernameField.setBounds(250, 155, 200, 35);

        passwordField = new JPasswordField();
        passwordField.setFont(f1);
        passwordField.setBounds(250, 215, 200, 35);

        registerBtn = new JButton("Register");
        registerBtn.setFont(f1);
        registerBtn.setBounds(340, 325, 215, 50);
        registerBtn.setBackground(Color.BLUE);
        registerBtn.setForeground(Color.WHITE);
        registerBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        registerBtn.addActionListener(this);

        resetBtn = new JButton("Reset");
        resetBtn.setFont(f1);
        resetBtn.setBounds(200, 400, 215, 50);
        resetBtn.setBackground(Color.PINK);
        resetBtn.setForeground(Color.WHITE);
        resetBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        resetBtn.addActionListener(this);

        backBtn = new JButton("Back");
        backBtn.setFont(f1);
        backBtn.setBounds(90, 325, 215, 50);
        backBtn.setBackground(Color.ORANGE);
        backBtn.setForeground(Color.WHITE);
        backBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        backBtn.addActionListener(this);

        // Add components to the frame
        frame.add(usernameLabel);
        frame.add(passwordLabel);
        frame.add(usernameField);
        frame.add(passwordField);
        frame.add(registerBtn);
        frame.add(resetBtn);
        frame.add(backBtn);
        frame.add(backgroundLabel);

        // Make frame visible
        frame.setVisible(true);
    }

    // Action listener for button clicks
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == registerBtn) {
            handleRegister();
        } else if (e.getSource() == resetBtn) {
            handleReset();
        } else if (e.getSource() == backBtn) {
            handleBack();
        }
    }

    // Method to handle register button click
    private void handleRegister() {
        String name = usernameField.getText();
        String pass = new String(passwordField.getPassword());

        if (name.isEmpty() || pass.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Username and Password cannot be empty.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (saveUserToFile(name, pass)) {
            JOptionPane.showMessageDialog(frame, "User registered successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            frame.dispose();
            new Home(); // Navigate to home
        } else {
            JOptionPane.showMessageDialog(frame, "Failed to save user data.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Method to save user data to a file
    private boolean saveUserToFile(String username, String password) { 
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(".\\Data\\user_data.txt", true))) {
            writer.write("Username: " + username + "\n");
            writer.write("Password: " + password + "\n");
            writer.write("\n");
            return true;
        } catch (IOException e) {
            System.err.println("Error saving user data: " + e.getMessage());
            return false;
        }
    }

    // Method to handle reset button click
    private void handleReset() {
        usernameField.setText("");
        passwordField.setText("");
    }

    // Method to handle back button click
    private void handleBack() {
        frame.dispose();
        new Home(); // Navigate to the Home screen
    }

    // Main method to launch the application
    public static void main(String[] args) {
        new Register();
    }
}
